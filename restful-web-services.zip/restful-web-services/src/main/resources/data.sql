insert into user values(101, '2019-01-21T05:47:26.853Z', 'Umesh');
insert into user values(102, '2019-01-21T05:47:26.853Z', 'Umesh2');
insert into user values(103, '2019-01-21T05:47:26.853Z', 'Umesh3');

insert into post values(201, 'My Post 1', 101);
insert into post values(202, 'My Post 2', 102);
insert into post values(203, 'My Post 3', 101);
