package com.umesh.interfacetest;

public class Employee extends Person {
	public Employee() {
		//super();
		//this();
		//System.out.print("Employee Called");
	}
	
	public static void main(String[] args) {
		Person e1 = new Employee();
		System.out.println(e1 instanceof Person);
		System.out.println(e1 instanceof Employee);
		
	}
}
