package com.umesh.interfacetest;

public class TestConstruct {
	
	private String name;

	public TestConstruct(String name) {
		
		this.name = name;
	}

	public TestConstruct() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	static {
		System.out.print("Yes");
	}
	
	public void main(String[] args) {
		System.out.print("Main");
	}
	
}
