package com.umesh.interfacetest;

public class Person {
	
	public Person() {
		System.out.print("Person");
	}
}


