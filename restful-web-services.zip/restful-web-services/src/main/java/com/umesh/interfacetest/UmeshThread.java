package com.umesh.interfacetest;

public class UmeshThread implements Runnable {
	
	public UmeshThread() {
		
	}
	public void run() {
		System.out.print("T1 started");
	}
	
	public static void main(String[] args) {
		UmeshThread t1 = new UmeshThread();
		//t1.start();
		t1.run();
		//t1.run();
		//t1.run();
		//t1.run();
		//t1.start();
		//try {
			//Thread.sleep(3000);
			//t1.wait();
			//t1.run();
			//t1.notify();
		//} catch (InterruptedException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		//}
		TestConstruct c = new TestConstruct();
	}
}
