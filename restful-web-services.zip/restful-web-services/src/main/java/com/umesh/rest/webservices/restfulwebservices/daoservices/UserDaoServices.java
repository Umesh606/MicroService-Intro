package com.umesh.rest.webservices.restfulwebservices.daoservices;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.umesh.rest.webservices.restfulwebservices.entity.User;

@Component
public class UserDaoServices {
	
	private static Integer userCount = 3;
	
	private static List<User> users = new ArrayList<User>();
	
	static {
		users.add(new User(1, "umesh1", Instant.now()));
		users.add(new User(2, "umesh2", Instant.now()));
		users.add(new User(3, "umesh3", Instant.now()));
	}

	public List<User>  getAllUsers() {
		return users;
	}
	
	public User saveUser(User user) {
		if (user.getId() == null) {
			user.setId(++userCount);
			users.add(user);
			return user;
		}
		return user;
	}
	
	public User getUserById(Integer id) {
		return users.stream().filter(user -> user.getId()==id).collect(Collectors.toList()).get(0);
	}

	public User deleteById(Integer id) {
		Iterator<User> iterator = users.iterator();
		while(iterator.hasNext()) {
			User next = iterator.next();
			if (next.getId().equals(id)) {
				users.remove(next);
				return next;
			}	
		}
		return null;
	}
}
