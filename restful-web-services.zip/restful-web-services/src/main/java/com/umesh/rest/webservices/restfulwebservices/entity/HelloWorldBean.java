package com.umesh.rest.webservices.restfulwebservices.entity;

import java.io.Serializable;

public class HelloWorldBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String message;
	
	

	public String getMessage() {
		return message;
	}



	public void setMessage(String message) {
		this.message = message;
	}



	public HelloWorldBean(String string) {
		message = string;
	}

}
