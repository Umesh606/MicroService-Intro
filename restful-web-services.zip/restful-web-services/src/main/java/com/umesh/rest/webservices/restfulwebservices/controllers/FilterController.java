package com.umesh.rest.webservices.restfulwebservices.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.umesh.rest.webservices.restfulwebservices.entity.SomeBean;

@RestController
public class FilterController {

	@GetMapping("/filter")
	public SomeBean filterProps() {
		return new SomeBean();
	}
}
