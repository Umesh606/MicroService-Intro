package com.umesh.rest.webservices.restfulwebservices.controllers;

import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.umesh.rest.webservices.restfulwebservices.entity.Post;
import com.umesh.rest.webservices.restfulwebservices.entity.User;
import com.umesh.rest.webservices.restfulwebservices.exception.UseNotFoundException;
import com.umesh.rest.webservices.restfulwebservices.repository.PostRepository;
import com.umesh.rest.webservices.restfulwebservices.repository.UserJpaRepository;

@RestController
@RequestMapping("/umesh")
public class UserJpaController {

	@Autowired
	public UserJpaRepository repository;
	
	@Autowired
	public PostRepository postRepository;
	
	@GetMapping("/jpa/users")
	public List<User> getAllUsers() {
		return repository.findAll();
	}
	
	@PostMapping("/jpa/saveUser")
	public ResponseEntity<User> saveUser(@Valid @RequestBody User user) {
		repository.save(user);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("{id}").buildAndExpand(user.getId()).toUri();
		return ResponseEntity.created(location).build();
	}
	
	@GetMapping("/jpa/findUser/{id}")
	public EntityModel<User> findUser(@PathVariable Integer id) {
			Optional<User> user = repository.findById(id);
			if (user.isPresent()) {
				EntityModel<User> model = EntityModel.of(user.get());
				WebMvcLinkBuilder builder = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(this.getClass()).getAllUsers());
				model.add(builder.withRel("all-users"));
				return model;
			}
			else {
				throw new UseNotFoundException("Cannot find suer with ID: " + id);
			}
	}
	
	@DeleteMapping("/jpa/delete/{id}")
	public void deleteUser(@PathVariable Integer id) {
		repository.deleteById(id);
	}
	
	@GetMapping("/jpa/{id}/posts")
	public List<Post> findPostsById(@PathVariable Integer id) {
		Optional<User> user = repository.findById(id);
		if (!user.isPresent()) {
			throw new UseNotFoundException("Can't find user id :" + id);
		}
		return user.get().getPosts();
		
	}
	
	@PostMapping("/jpa/{id1}/createPost")
	public ResponseEntity<Object> createPost(@PathVariable Integer id1, @RequestBody Post post) {
		Optional<User> user = repository.findById(id1);
		if (!user.isPresent()) {
			throw new UseNotFoundException("User id : " + id1 + " Not found");
		}
		post.setUser(user.get());
		postRepository.save(post);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("id").buildAndExpand(user.get().getId()).toUri();
		return ResponseEntity.created(uri).build();
	}
}
