package com.umesh.rest.webservices.restfulwebservices.controllers;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.umesh.rest.webservices.restfulwebservices.daoservices.UserDaoServices;
import com.umesh.rest.webservices.restfulwebservices.entity.User;
import com.umesh.rest.webservices.restfulwebservices.exception.UseNotFoundException;

@RestController
@RequestMapping("/umesh")
public class UsersController {

	@Autowired
	public UserDaoServices userDaoServices;
	
	@GetMapping("/users")
	public List<User> getAllUsers() {
		return userDaoServices.getAllUsers();
	}
	
	@PostMapping("/saveUser")
	public ResponseEntity<User> saveUser(@Valid @RequestBody User user) {
		userDaoServices.saveUser(user);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("{id}").buildAndExpand(user.getId()).toUri();
		return ResponseEntity.created(location).build();
	}
	
	@GetMapping("/findUser/{id}")
	public EntityModel<User> findUser(@PathVariable Integer id) {
		try {
			User user = userDaoServices.getUserById(id);
			EntityModel<User> model = EntityModel.of(user);
			WebMvcLinkBuilder builder = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(this.getClass()).getAllUsers());
			model.add(builder.withRel("all-users"));
			return model;
		} catch (Exception ex) {
			throw new UseNotFoundException(String.format("Id: %s", id));
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteUser(@PathVariable Integer id) {
		User user = userDaoServices.deleteById(id);
		if (user == null) {
			throw new UseNotFoundException("Id: " + id);
		}
	}
}
