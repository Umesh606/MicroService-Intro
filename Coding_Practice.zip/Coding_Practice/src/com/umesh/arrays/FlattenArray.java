/*
 * Put your copyright text here
 */
package com.umesh.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FlattenArray {
	public static void main(String[] args) throws Exception{
		final Object[] array = { 1, 2, new Object[]{ 3, 4, new Object[]{ 5 }, 6, 7 }, 8, 9, 10 };

		final Integer[] flattenedArray = flatten(array);

		System.out.println(Arrays.toString(flattenedArray));
	}

	public static Integer[] flatten(Object[] inputArray) throws Exception {
		final List<Integer> result = new ArrayList<>();
		for (final Object obj : inputArray) {
			if (obj instanceof Integer) {
				result.add((Integer)obj);
			}
			else if(obj instanceof Object[]) {
				result.addAll(List.of(flatten((Object[])obj)));
			}
			else {
				throw new Exception("Unable to flatten the array");
			}
		}
		final Integer[] finals = new Integer[result.size()];
		return result.toArray(finals);
	}
}
