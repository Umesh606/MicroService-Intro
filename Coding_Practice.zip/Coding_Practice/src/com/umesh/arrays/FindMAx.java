/*
 * Put your copyright text here
 */
package com.umesh.arrays;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FindMAx {
	//List<Integer> list = List.o

	public static void main(String[] args) {

		//generate password logic

		// sum of all even numbers

		//		public Integer findSumOfEvenNumbers(List<Integer> intList) {
		//			return intList.stream().filter(num -> num%2 == 0).collect(Collectors.toSumming());
		//		}
		// finding max
		final List<Integer> intList = List.of(2, 10, 7, 5, 22, 34, 0, 6, 90);
		final Integer sum = intList.stream().mapToInt(x -> x).sum();
		System.out.println("Sum : " + sum);

		final Integer result = intList.stream().filter(x -> x%2==1).collect(Collectors.summingInt(x->x));
		System.out.println("Without sum: " + result);

		final Integer max = intList.stream().max(Comparator.comparing(x->x)).get();
		System.out.println("Max: " + max);

		// first non repeating char
		final String str = "aapplle";
		final Map<Character, Integer> countMap = new LinkedHashMap<>();
		final char[] arrayStr = str.toCharArray();
		for (final Character ch : arrayStr) {
			countMap.put(ch, countMap.containsKey(ch)?countMap.get(ch)+1:1);
		}
		final Character ch1 = countMap.entrySet().stream().filter(entry -> entry.getValue()==1).findFirst().get().getKey();
		System.out.println("First non repeating : " + ch1);
	}
}
