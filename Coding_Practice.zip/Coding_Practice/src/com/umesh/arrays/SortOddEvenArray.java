package com.umesh.arrays;

public class SortOddEvenArray {

		public static void main(String[] args) {
			System.out.println("Umesh");
			int[] intArr = {1, 3, 12, 23, 20, 9, 6, 36, 37, 40, 44, 45};
			
			intArr = sortOddEven(intArr);
			for (int i=0; i<intArr.length; i++) {
				System.out.println(intArr[i]);
			}
 		}

		private static int[] sortOddEven(int[] intArr) {
			int left = 0, right=intArr.length-1;
			for (int i=0; i<intArr.length; i++) {
				while(intArr[left]%2 == 0) {
					left++;
					//System.out.println(left);
				}
				while (intArr[right] %2 == 1) {
					right--;
					//System.out.println(right);
				}
				if (left <right) {
					int temp = intArr[left];
					intArr[left] = intArr[right];
					intArr[right] = temp;
				}
			}
			return intArr;
		}
}
