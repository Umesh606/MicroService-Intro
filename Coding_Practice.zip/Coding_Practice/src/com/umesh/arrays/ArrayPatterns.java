/*
 * Put your copyright text here
 */
package com.umesh.arrays;

public class ArrayPatterns {

	public static void main(String[] args) {

		final int[] array = {1,2,3,4,5,6};
		final String  str = new String("");
		final int row= 3, colun= 10;
		//
		//		1,2,3,4,5
		//		6,1,2,3,4
		//		5,6,1,2,3

		//		final int result[][] = new int[50][50];
		//
		////		final int row = 3, col = 3;
		//
		//		for (int i=0; i< row; i++) {
		//			for (int j=0; j< row-i; j++) {
		//				result[i][j] = array[j];
		//			}
		//			//System.out.println("");
		//		}
		int pos = 0;
		final int count = array.length;
		for (int i=0; i<row; i++) {

			int j = pos+i;
			while(j < colun) {

				pos = j%count;
				System.out.print(array[pos]);
				System.out.print(",");
				j++;
			}
			System.out.println();
		}
	}

}
