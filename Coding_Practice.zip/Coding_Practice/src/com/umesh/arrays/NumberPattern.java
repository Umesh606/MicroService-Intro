/*
 * Put your copyright text here
 */
package com.umesh.arrays;

/**
 *
 * 200
400 600
300
600 900 1200
400
800 1200 1600 2000

 * @author ubasappa
 *
 */
public class NumberPattern {

	public static void main(String[] args) {

		final int rows = 5;
		for (int i=2; i<rows; i++) {

			for (int j=1; j<=i+1; j++) {

				if (j==1) {
					System.out.println(i*j*100);
				}
				else {
					System.out.print(i*j*100 + " ");
				}
			}
			System.out.println();
		}
	}
}
