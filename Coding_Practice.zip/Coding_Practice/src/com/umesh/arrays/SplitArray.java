/*
 * Put your copyright text here
 */
package com.umesh.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SplitArray {

	public static void main(final String[] args) {
		final int[] original = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		final int splitSize = 3;

		/* expected Output
			[0, 1, 2]
			[3, 4, 5]
			[6, 7, 8]
			[9]
		 */

		final List<int[]> list = splitArray(original, splitSize);
		list.forEach(splitArray -> System.out.println(Arrays.toString(splitArray)));
	}

	public static List<int[]> splitArray(int[] array, int splitSize) {
		final List<int[]> intList = new ArrayList<>();
		int start = 0;
		int end = 0;
		final int arrayCount = array.length/splitSize;
		final int reminder = array.length%splitSize;

		for (int i=0; i<arrayCount; i++) {
			end += splitSize;
			intList.add(Arrays.copyOfRange(array, start, end));
			start = end;
		}
		if (reminder > 0) {
			intList.add(Arrays.copyOfRange(array, start, array.length));
		}
		return intList;
	}

}
