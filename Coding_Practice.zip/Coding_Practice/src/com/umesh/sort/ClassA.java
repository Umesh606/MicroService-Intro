package com.umesh.sort;

public class ClassA implements ClassI {

}
