/*
 * Put your copyright text here
 */
package com.umesh.list;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ListIteratorTest {

	public static void main(String[] args) {
		final List<String> names = new LinkedList<>();
		names.add("Rams");
		names.add("Posa");
		names.add("Chinni");

		//		// Getting ListIterator
		final ListIterator<String> namesIterator = names.listIterator();

		// Traversing elements
		while(namesIterator.hasNext()){
			namesIterator.add("ABCD");
			namesIterator.remove();
			//System.out.println(namesIterator.remove());
		}

		// Enhanced for loop creates Internal Iterator here.
		for(final String name: names){
			System.out.println(name);
		}
	}
}
