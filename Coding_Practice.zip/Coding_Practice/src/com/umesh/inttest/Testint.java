package com.umesh.inttest;

public class Testint {

	public static void main(String[] args) {  
		  Integer i = 1000;  
		  Integer j = 201;
		  System.out.println(i);
		  System.out.println(j);
		  if(i == j)  
		  {  
		    System.out.println("hello");  
		  }  
		  else   
		  {  
		    System.out.println("bye");  
		  } 
	}
}
