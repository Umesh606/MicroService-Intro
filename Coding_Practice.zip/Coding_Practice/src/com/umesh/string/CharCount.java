/*
 * Put your copyright text here
 */
package com.umesh.string;

import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class CharCount {

	static final int ASCII_SIZE = 256;
	static char getMaxOccurringChar(String str)
	{
		// Create array to keep the count of individual
		// characters and initialize the array as 0
		final int count[] = new int[250];

		// Construct character count array from the input
		// string.
		final int len = str.length();
		//		for (int i = 0; i < len; i++)
		//			count[str.charAt(i)]++;

		//		for (int i =0; i<count.length; i++)
		//			System.out.print(count[i]);

		int max = -1; // Initialize max count
		char result = ' '; // Initialize result

		// Traversing through the string and maintaining
		// the count of each character
		for (int i = 0; i < len; i++) {
			System.out.print(count[str.charAt(i)]);
			if (max < count[str.charAt(i)]) {
				max = count[str.charAt(i)];
				result = str.charAt(i);
			}
		}

		return result;
	}

	public static void main(String[] args)
	{
		final String str = "sample lssttttrrriiing";
		System.out.println("Max occurring character is "
				+ maximumOccuringChar(str));

	}

	public static Map<Object, Long> maximumOccuringChar(String str) {
		final Map<Object, Long> collect = str.chars().mapToObj(x -> (char) x).collect(Collectors.groupingBy(x->x, Collectors.counting()));


		// Collections.sort(collect);
		final Map<Object, Long> result = str.chars()
				.mapToObj(x -> (char) x)                  // box to Character
				.collect(Collectors.groupingBy(x -> x, Collectors.counting()));  // collect to Map<Character, Long>

		System.out.println(result);
		return result;
	}

	private static Comparator<? super Entry<Character, Long>> comparingByValue() {

		return null;
	}

}
