/*
 * Put your copyright text here
 */
package com.umesh.string;

public class PalindromeStr {

	public static void main(String[] args) {

		final String str = "GADAG";

		String result = "";

		for (int i=str.length()-1; i>=0; i--) {
			result += str.charAt(i);
		}
		System.out.println(result.equals(str));
	}
}
