/*
 * Put your copyright text here
 */
package com.umesh.string;

public class NumberPattern1 {

	public static void main(String[] args) {

		final int i=5;

		for (int j=2; j<=i; j++) {

			// System.out.println(j*100);
			for (int k=1; k<=j+1; k++) {
				if (k==1) {
					System.out.println(k*j*100);
				}
				else {
					System.out.print(k*j*100);
					System.out.print(" ");
				}
			}
			System.out.println("");
		}
	}
}
