/*
 * Put your copyright text here
 */
package exception;

public class TestException5 extends TestException4 {

	@Override
	public void start() {
		System.out.print("E5 - start");
	}

	@Override
	public void foo() throws RuntimeException{
		System.out.print("E5 - foo");
	}

	public static void main(String[] args) {
		final TestException4 e4 = new TestException5();
		final TestException5 e5 =(TestException5) new TestException4();
		e4.foo();
		//e41.foo();
	}
}
