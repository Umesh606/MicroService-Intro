/*
 * Put your copyright text here
 */
package exception;

public class TestException4 {

	public void start() throws ArithmeticException {
		System.out.print("E4 - start");
	}

	public void foo() throws NullPointerException{
		System.out.print("E4 - foo");
	}

}
