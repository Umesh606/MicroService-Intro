/*
 * Put your copyright text here
 */
package streams;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class CountOfDepartmnet {

	public static void main(String[] args) {
		final Employee e1 = new Employee("name1", "department1");
		final Employee e2 = new Employee("name2", "department2");
		final Employee e3 = new Employee("name3", "department3");
		final Employee e4 = new Employee("name4", "department1");
		final Employee e5 = new Employee("name5", "department2");
		final Employee e6 = new Employee("name6", "department3");
		final Employee e7 = new Employee("name7", "department1");

		final List<Employee> list = new ArrayList<>();
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		list.add(e5);
		list.add(e6);
		list.add(e7);
		// list.stream().filter(e1 -> e1.getDepartment())
		//Map<String, Long> result = list.stream().collect(Collectors.groupingBy(Employee::getDepartment, TreeMap::new, Collectors.counting()));
		System.out.println(list.stream().collect(Collectors.groupingBy(Employee::getDepartment, TreeMap::new, Collectors.counting())));
		//		System.out.print(result);
		final Map<String, List<Employee>> resultMap = list.stream().collect(Collectors.groupingBy(Employee::getDepartment));
		System.out.println(resultMap);
		resultMap.forEach((key, value) -> {
			value.forEach(e -> System.out.printf("%n" + e.getDepartment()));
		});
	}
}
